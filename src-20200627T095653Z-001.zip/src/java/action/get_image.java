/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package action;


/**
 *
 * @author IBN33
 */
public class get_image {
    
}
